import './App.css';
import MainTab from './components/tabs/mainTab/MainTab';

function App() {
  return (
    <div className='App'>
      <MainTab />
    </div>
  );
}

export default App;